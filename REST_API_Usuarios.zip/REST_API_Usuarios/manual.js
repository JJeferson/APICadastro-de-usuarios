/*
npm install -- save express
npm install -- save-dev nodemon
npm install -g nodemon 
npm install --save morgan
npm install --save body-parse
npm install --save mysql


Teste
node server.js
nodemon server.js

*/